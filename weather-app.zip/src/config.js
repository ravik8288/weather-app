import icon from './assets/Icons/time.svg';
import temp from './assets/Icons/temp.svg';

const config = {
  time_icon: icon,
  temp_icon:temp
};

export default config;
